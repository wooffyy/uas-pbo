package model.card;

// Enum inner-scope / Suit: ♠♥♦♣
public enum Suit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
