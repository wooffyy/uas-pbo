package model.card;

public enum EffectTrigger {
    BEFORE_STAGE,
    AFTER_STAGE,
    BEFORE_ROUND,
    ON_ROUND,
    AFTER_ROUND
}
