package model.card;

public enum Rarity {
    COMMON, RARE, SUPER_RARE, LEGENDARY;
}
